package com.enricophie.flutter_clima_weather_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
